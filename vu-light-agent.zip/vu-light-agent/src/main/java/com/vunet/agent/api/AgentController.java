package com.vunet.agent.api;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class AgentController {
    // Endpoints moved to HealthController
}
