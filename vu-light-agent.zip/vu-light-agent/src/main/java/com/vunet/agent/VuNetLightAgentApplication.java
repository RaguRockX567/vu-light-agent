package com.vunet.agent;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

/**
 * Spring Boot entry point for the VuNet Light Agent. Starts the web server
 * (Tomcat) and launches the agent background thread.
 */
@SpringBootApplication(scanBasePackages = "com.vunet.agent")
public class VuNetLightAgentApplication {

    public static void main(String[] args) {
        SpringApplication.run(VuNetLightAgentApplication.class, args);
    }

    // --- Background startup ---
    @Bean
    public CommandLineRunner startAgentRunner() {
        return args -> {
            System.out.println("[Spring] Application started — launching agent background thread");
            try {
                AgentMain.startAgent();
            } catch (Exception e) {
                System.err.println("[Spring] Failed to start agent: " + e.getMessage());
                e.printStackTrace();
            }
        };
    }
}
