package com.vunet.agent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.vunet.agent")
public class AgentApplication {
    public static void main(String[] args) {
        System.out.println("🚀 VuNet LightAgent — Spring REST API starting...");
        SpringApplication.run(AgentApplication.class, args);
    }
}